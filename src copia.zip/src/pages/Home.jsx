import React from 'react';
import { Container } from 'react-bootstrap';

function Home() {
  return (
    <Container className="text-center my-5">
      <h1>Benvenuti nella vetrina di Erwin Hidalgo</h1>
    </Container>
  );
}

export default Home;
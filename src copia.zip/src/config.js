const config = {
    apiBaseUrl: 'http://localhost:3001', 
  };
  
  export default config;